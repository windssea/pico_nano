"""本地网页安装入口。 / Local web installer entry point."""
import argparse
import functools
import http.server
import pathlib

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--port', type=int, default=8765)
args = parser.parse_args()
root = pathlib.Path(__file__).resolve().parent
handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(root))
print(f'Open http://localhost:{args.port}/ in Chrome or Edge; keep this terminal open.', flush=True)
http.server.ThreadingHTTPServer(('127.0.0.1', args.port), handler).serve_forever()
