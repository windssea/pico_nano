import os,pathlib,http.server
os.chdir(pathlib.Path(__file__).resolve().parent)
print("Open http://localhost:8765/ in Chrome/Edge")
http.server.ThreadingHTTPServer(("127.0.0.1",8765),http.server.SimpleHTTPRequestHandler).serve_forever()
